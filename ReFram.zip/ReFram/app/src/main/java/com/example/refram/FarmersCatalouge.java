package com.example.refram;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FarmersCatalouge extends AppCompatActivity {
    Button tax_btn,loan_btn,products_btn,retailers_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmers_catalouge);
        tax_btn = findViewById(R.id.button7);
        loan_btn = findViewById(R.id.button8);
        retailers_button = findViewById(R.id.button9);
        products_btn = findViewById(R.id.button10);


    }
    public void onStart(){
        super.onStart();

        products_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent catalogue = new Intent(getApplicationContext(),ProductsCatalogue.class);
                startActivity(catalogue);
            }
        });
        tax_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Intent onTax = new Intent(getApplicationContext(),tax.class);
                    startActivity(onTax);
            }
        });
        loan_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent onloan = new Intent(getApplicationContext(),Loan.class);
                startActivity(onloan);

            }
        });
        retailers_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent retailer = new Intent(getApplicationContext(),retailerwebsite.class);
                startActivity(retailer);
            }
        });
    }
}
