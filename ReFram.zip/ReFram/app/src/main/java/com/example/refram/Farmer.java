package com.example.refram;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Farmer extends AppCompatActivity {
    Button loginFarmer = null;
    EditText getPhoneNumber = null;
    Intent loginAuthFarmer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer);
        loginFarmer =(Button) findViewById(R.id.button_loginAuth);
        getPhoneNumber =(EditText) findViewById(R.id.editText_farmer_phone_number);
        loginFarmer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginAuthFarmer = new Intent(getApplicationContext(),FarmersCatalouge.class);

                if(getPhoneNumber.getText().toString().length() !=0){         //get the phone number from the field  as a string and check
                    loginAuthFarmer.putExtra("phoneNumber",getPhoneNumber.getText().toString());
                    Toast.makeText(getApplicationContext(),getPhoneNumber.getText(),Toast.LENGTH_SHORT).show();
                    startActivity(loginAuthFarmer);
                }
                }





        });
    }
}
